from django.shortcuts import render
from twilio.rest import Client
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
account_sid = 'ACff3af7c289edb6bc289fd34b26c15c8c'
auth_token = 'adf167013cef3f0aa8492a7ff140059d'
client = Client(account_sid, auth_token)
@csrf_exempt
def bot(request):
    message = request.POST["Body"]
    sender_name = request.POST["ProfileName"]
    sender_number =request.POST["From"]
    #print(request.POST)
    print(message)
    print(sender_name)
    if messahe == "hi": # type: ignore
        client.messages.create(
                           from_='whatsapp:+14155238886',
                            content_sid='HXb5b62575e6e4ff6129ad7c8efe1f983e',
                            body='Hello there!',
                            content_variables='{"1":"12/1","2":"3pm"}',
                            to='whatsapp:+919567896002' 
       )
    return HttpResponse("hello")